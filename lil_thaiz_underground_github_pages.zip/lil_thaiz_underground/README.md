# LIL THAIZ$ — Underground Website

Website tĩnh dùng HTML, CSS và JavaScript, tương thích GitHub Pages.

## Đăng lên GitHub Pages
1. Tạo repository mới, ví dụ `lil-thaiz`.
2. Upload `index.html`, `README.md` và thư mục `assets`.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch**, nhánh `main`, thư mục `/(root)`, rồi Save.

## Thêm nhạc
- Tạo thư mục `assets`.
- Đưa file MP3 của bạn vào và đặt tên `track.mp3`.
- Đường dẫn player đã trỏ tới `assets/track.mp3`.

## Tùy chỉnh
- Sửa tên, giới thiệu, lyrics và các link mạng xã hội trong `index.html`.
- Chỉ dùng nhạc/hình ảnh mà bạn có quyền sử dụng.
